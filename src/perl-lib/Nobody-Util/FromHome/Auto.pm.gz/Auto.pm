BEGIN { say STDERR __FILE__ };
package Nobody::Auto;
use Carp::Always;
use Nobody::PP qw(eex);

sub import {
  die "fuck";
};
#sub import {
#  eex(\@_);
#};
#    use Nobody::PP qw(eex);
#    sub import {
#      for(0 .. 3) {
#        eex([caller]);
#        eex(caller($_));
#      };
#    };

1;
